<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Group;

class ApitestController extends Controller
{
     // facilitoterGroupList
     public function apiGroupList($id=null)
     {
       
        // $groups= Group::all();
        return $id?Group::find($id):Group::all();
        // return response()->json(["groups"=>$groups],200); 
        $data= $group->apiGroupList();          
        if($data){
            return response()->json([
                'status' => 1,
                'success' => true,
                'code'=>200,
                'message' => "successfully list",
                'data' => (object)[]
            ], 200);
        }else{
            return response()->json([
                'status' => 0,
                'success' => false,
                'code'=>200,
                'message' => "data not found",
                'data' => (object)[]
            ], 200);
        }
       
     }
}
