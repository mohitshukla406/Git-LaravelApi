<?php
namespace App\Http\Controllers;
use JWTAuth;
use App\Models\User;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Exceptions\JWTException;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use App\Models\Otpsession;
use App\Models\User_parent;
use App\Models\Total_star;
use App\Models\Final_star;
use App\Models\Avtar;
use App\Models\Faq;
use Illuminate\Support\Facades\Auth;
use Postal\Client;
use App\Helpers\Frontend;
use App\Models\group;
use App\Models\groupregister;
class ApiFacilitoterController extends Controller
{
    // facilitoterCreateGroup
    public function facilitatorCreateGroup(Request $request)
    {        
        $rules = array(
            'user_id' => 'required',
            'group' => 'required',           
            'number_student' => 'required'          
        );
        $messages = array(
            'user_id' => 'required',
            'group' => 'required',           
            'number_student' => 'required'          
        );       
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            // dd($errors);
            return response()->json([
                'status' => 0,
                'success' => false,
                'code'=>200,
                'message' => $errors[0],
                'data' => (object)[]
            ], 200);
        }
 
        $group= new Group;
        $group->user_id=$request->user_id;
        $group->group=$request->group;
        $group->number_student=$request->number_student;
        $data=$group->save();
        if($data){
            return response()->json([
                'status' => 1,
                'success' => true,
                'code'=>200,
                'message' => "समूह सफलतापूर्वक बनाया गया",
                'data' => (object)[]
            ], 200);
        }else{
            return response()->json([
                'status' => 0,
                'success' => false,
                'code'=>200,
                'message' => "समूह संचालन विफल",
                'data' => (object)[]
            ], 200);
        }
    }
     // facilitoterUpdateGroup
     public function facilitatorUpdateGroup(Request $request)
     {  
        
        
         $rules = array(
             'group_id'=>'required',
             'user_id' => 'required',
             'group' => 'required',           
             'number_student' => 'required'           
         );
         $messages = array(
            'group_id'=>'required',
             'user_id' => 'required',
             'group' => 'required',           
             'number_student' => 'required'          
         );        
         $validator = Validator::make($request->all(), $rules, $messages);
         if ($validator->fails()) {
             $messages = $validator->messages();
             $errors = $messages->all();
             // dd($errors);
             return response()->json([
                 'status' => 0,
                 'success' => false,
                 'code'=>200,
                 'message' => $errors[0],
                 'data' => (object)[]
             ], 200);
         }
  
         $group= Group::find($request->group_id);
         $group->user_id=$request->user_id;
         $group->group=$request->group;
         $group->number_student=$request->number_student;
         $data=$group->update();
         if($data){
             return response()->json([
                 'status' => 1,
                 'success' => true,
                 'code'=>200,
                 'message' => "सफलतापूर्वक अद्यतन करें",
                 'data' => (object)[]
             ], 200);
         }else{
             return response()->json([
                 'status' => 0,
                 'success' => false,
                 'code'=>200,
                 'message' => "अद्यतन विफल रहा",
                 'data' => (object)[]
             ], 200);
         }
     }
         // facilitoterGroupList
         public function facilitatorGroupList($id=null)
         {
           
            // $groups= Group::all();
            return $id?Group::find($id):Group::all();
            // return response()->json(["groups"=>$groups],200); 
            $data= $group->facilitatorGroupList();          
            if($data){
                return response()->json([
                    'status' => 1,
                    'success' => true,
                    'code'=>200,
                    'message' => "सूची समूह दृश्य",
                    'data' => (object)[]
                ], 200);
            }else{
                return response()->json([
                    'status' => 0,
                    'success' => false,
                    'code'=>200,
                    'message' => "सूची समूह विफल",
                    'data' => (object)[]
                ], 200);
            }
           
         }

          // facilitoterGroupDelete
          public function facilitatorGroupDelete($id, Request $request)
          {
            $group= Group::find($id);
            $data= $group->delete();
             if($data){
                return response()->json([
                    'status' => 1,
                    'success' => true,
                    'code'=>200,
                    'message' => "हटाना सफल",
                    'data' => (object)[]
                ], 200);
            }else{
                return response()->json([
                    'status' => 0,
                    'success' => false,
                    'code'=>200,
                    'message' => "हटाना विफल",
                    'data' => (object)[]
                ], 200);
            }
         
          }

    
           //  Facilitator Registration API
    public function facilitatorRegisterAPI(Request $request)
    {
        $rules = array(
            'name' => 'required|regex:/^[\pL\s\-]+$/u',
            'username' => 'required|regex:/^[\pL\s\-]+$/u',         
            'email' => 'required',
            'dob' => 'required',          
            'password' => 'required',
            'role_id' => 'required'
        );
        $messages = array(
            'name.required'     => 'कृपया एक नाम दर्ज करें.',
            'username.alpha'     => 'कृपया मान्य नाम दर्ज करें.', 
            'email.required'      => 'ईमेल या फोन की आवश्यकता है',
            'dob.required'    => 'कृपया जन्म तिथि दर्ज करें',                    
            'password.required' => 'कृपया पासवर्ड दर्ज करें.',
            'role_id.required'   => 'उपयोगकर्ता नाम पहले से मौजूद.',
        );
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            // dd($errors);
            return response()->json([
                'status' => 0,
                'success' => false,
                'code'=>200,
                'message' => $errors[0],
                'data' => (object)[]
            ], 200);
        }
        $con_date = str_replace('/','-',$request->dob);
        $dob = date("Y-m-d",strtotime($con_date));
        // get year
        $year = date('Y',strtotime($dob));
        if($year < 1800)
        {
            return response()->json([
                'status' => 0,
                'success' => false,
                'code'=>200,
                'message' => "कृपया मान्य आयु दर्ज करें",
                'data' => (object)[]
            ], 200);
        }
        // check date of birth
        $today = date("Y-m-d");
        $diff = date_diff(date_create($dob), date_create($today));
        $age = $diff->format('%y');
        $type = 'student';
        if($age >= 11 && $age < 18 )
        {
            $type = 'parent';
        }
       $phone = '';
       $email = '';
       $flag = 0;
        $mob="/^[1-9][0-9]*$/";
        if(preg_match($mob,$request->mobemail))
        {
            if(strlen($request->mobemail)<10)
            {
                return response()->json([
                    'status' => 0,
                    'success' => false,
                    'code'=>200,
                    'message' => "कृपया एक वैध नंबर डालें",
                    'data' => (object)[]
                ], 200);
            }
            $phone = $request->mobemail;
            $flag = 1;// for phone
        }else{
            $emailval = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/';
            if(!preg_match($emailval, $request->mobemail)){
                return response()->json([
                    'status' => 0,
                    'success' => false,
                    'code'=>200,
                    'message' => "कृपया वैध ईमेल दर्ज़ करें",
                    'data' => (object)[]
                ], 200);
            }
            $email = $request->mobemail;
            $flag = 0;// for phone
        }
        if(!empty($request->user_name))
        {
            $usernameExist = Groupregister::where('logUsername',$request->username)->first();
            if(!empty($usernameExist))
            {
                return response()->json([
                    'status' => 0,
                    'success' => false,
                    'code'=>200,
                    'message' => "यूजर का नाम पहले से मौजूद है",
                    'data' => (object)[]
                ], 200);
            }
        }
        $credentials =array();
        if($flag == 1)
        {
            $credentials = array(
                'phone'=> $request->mobemail,
                'password'=>$request->password
            );
        }else
        {
            $credentials = array(
                'email'=> $request->mobemail,
                'password'=>$request->password
            );
        }
        $hashed = Hash::make($request->password);
        $user_unique_id = time().uniqid();
        if($type == 'parent')
        {
            $userData = array(
                'role_id'=>'15',
                "parent_id"=>'1',
                'name'=>$request->fullName,
                'firstname'=>$request->fullName,
                'dob'=>$dob,
                'logUsername'=>$request->username,
                'user_unique_id'=>$user_unique_id,
                'ip_address'=>$request->ip(),
              'password'=>$hashed,
                'email'=>$email,
                'phone'=>$phone,
                'gender'=>$request->gender,
            );
           $res =  Groupregister::create($userData);
           $user_id = $res->id;
            $parent_data = array(
                'user_id'=>$user_id,
                'email'=>$email,
                'phone'=>$phone,
                // 'firstname'=>$request->firstname,
                // 'lastname'=>$request->lastname,
                'gender'=>$request->gender,
            );
            $res = User_parent::create($parent_data);
            $data = array(
                'id'=>$user_id,
                'name'=>$request->fullName,
                'user_unique_id'=>$user_unique_id
            );
               try {
                if (!$token = JWTAuth::attempt($credentials)) {
                    return response()->json([
                        'status' => 0,
                    'success' => false,
                    'code'=>400,
                    'message' => "टोकन नहीं बनाया गया",
                    'data' => (object)[]
                    ], 400);
                }
            } catch (JWTException $e) {
                return $credentials;
                return response()->json([
                    'status' => 0,
                    'success' => false,
                    'code'=>500,
                    'message' => "टोकन नहीं बनाया गया",
                    'data' => (object)[]
                ], 500);
            }
             return response()->json([
                 'status' => 1,
                 'success' => true,
                 'code'=>200,
                 'message' => "पंजीकरण सफलतापूर्वक किया गया",
                 'data' => $data,
                 'token'=>$token
             ], 200);
        }
        if($type == 'student')
        {
            if(!empty($email))
            {
                $emailExist = User::where('email',$email)->first();
                if(!empty($emailExist))
                {
                    return response()->json([
                        'status' => 0,
                        'success' => false,
                        'code'=>200,
                        'message' => "ईमेल पहले से मौजूद है",
                        'data' => (object)[]
                    ], 200);
                }
            }
            if(!empty($phone))
            {
                $phoneExist = Groupregister::where('phone',$phone)->first();
                if(!empty($phoneExist))
                {
                    return response()->json([
                        'status' => 0,
                        'success' => false,
                        'code'=>200,
                        'message' => "फ़ोन पहले से मौजूद है",
                        'data' => (object)[]
                    ], 200);
                }
            }
            $loginEmail = (!empty($email)) ? $email :"";
            $userData = array(
                'role_id'=>'15',
                "parent_id"=>'0',
                'name'=>$request->fullName,
                'username'=>$request->fullName,
                'dob'=>$dob,
                'logUsername'=>$request->username,
                'user_unique_id'=>$user_unique_id,
                'ip_address'=>$request->ip(),
              'password'=>$hashed,
                'email'=>$loginEmail,
                'phone'=>$phone,
                'gender'=>$request->gender,
            );
           $res = Groupregister::create($userData);
           $data = array(
               'id'=>$res->id,
               'name'=>$request->fullName,
               'user_unique_id'=>$user_unique_id
           );
              try {
               if (!$token = JWTAuth::attempt($credentials)) {
                   return response()->json([
                    'status' => 0,
                    'success' => false,
                    'code'=>400,
                    'message' => "टोकन नहीं बनाया गया",
                    'data' => (object)[]
                   ], 400);
               }
           } catch (JWTException $e) {
               return $credentials;
               return response()->json([
                'status' => 0,
                'success' => false,
                'code'=>500,
                'message' => "फ़ोन पहले से मौजूद है",
                'data' => (object)[]
               ], 500);
           }
            return response()->json([
                'status' => 1,
                'success' => true,
                'code'=>200,
                'message' => "पंजीकरण सफलतापूर्वक किया गया",
                'data' => $data,
                "token"=>$token
            ], 200);
        }
    }

          public function facilitatorlogin(Request $request)
          {
            // check email or phone
            $flag = 0;
            $mob="/^[1-9][0-9]*$/";
            $username= "/^[a-zA-Z]+$/";
            $__username= "/^[a-zA-Z0-9]+$/";
            $____username= "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+$/";
            $email = "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i";
            $rules = $request->all();
            if(preg_match($mob,$request->email))
            {
                $rules = array(
                    'email' => 'required|numeric',
                    'password' => 'required'
                );
                $messages = array(
                    'email.required'     => 'कृपया फ़ोन दर्ज करें',
                    'email.required'    => 'मोबाइल नंबर न्यूमेरिक होना चाहिए',
                    'password.required' => 'कृपया पासवर्ड दर्ज करें'
                );
                $flag = 1; // for phone
            }else if(preg_match($username,$request->email)){
                $rules = array(
                    'email' => 'required',
                    'password' => 'required'
                );
                $messages = array(
                    'email.required'     => 'कृपया उपयोगकर्ता नाम दर्ज करें',
                    'email.required'    => 'उपयोगकर्ता नाम अल्फा होना चाहिए।',
                    'password.required' => 'कृपया पासवर्ड दर्ज करें।'
                );
                $flag = 2; // for username
            }else if(preg_match($__username,$request->email)){
                $rules = array(
                    'email' => 'required',
                    'password' => 'required'
                );
                $messages = array(
                    'email.required'     => 'कृपया उपयोगकर्ता नाम दर्ज करें',
                    'email.required'    => 'उपयोगकर्ता नाम अल्फा होना चाहिए।',
                    'password.required' => 'कृपया पासवर्ड दर्ज करें।'
                );
                $flag = 2; // for username
            }else if(preg_match($____username,$request->email)){
                $rules = array(
                    'email' => 'required',
                    'password' => 'required'
                );
                $messages = array(
                    'email.required'     => 'कृपया उपयोगकर्ता नाम दर्ज करें',
                    'email.required'    => 'उपयोगकर्ता नाम अल्फा होना चाहिए।',
                    'password.required' => 'कृपया पासवर्ड दर्ज करें।'
                );
                $flag = 2; // for username
            }else if(preg_match($email,$request->email)){
                $rules = array(
                    'email' => 'required|email',
                    'password' => 'required',
                );
                $messages = array(
                    'email.required'    => 'कृपया ईमेल दर्ज करें.',
                    'email.unique'    => 'ईमेल पहले से मौजूद है.',
                    'password.required' => 'कृपया पासवर्ड दर्ज करें.',
                    'email.email' => 'ईमेल एक मान्य ईमेल पता होना चाहिए'
                );
                $flag = 0; // for email
            }else{
                $rules = array(
                    'email' => 'required|email',
                    'password' => 'required',
                );
                $messages = array(
                    'email.required'    => 'कृपया ईमेल दर्ज करें.',
                    'email.unique'    => 'ईमेल पहले से मौजूद है.',
                    'password.required' => 'कृपया पासवर्ड दर्ज करें.',
                    'email.email' => 'ईमेल एक मान्य ईमेल पता होना चाहिए'
                );
                $flag = 0; // for email
            }
            //valid credential
            $validator = Validator::make($request->all(), $rules,$messages);
            if ($validator->fails()) {
                $messages = $validator->messages();
                $errors = $messages->all();
                // dd($errors);
                return response()->json([
                    'status' => 0,
                    'success' => false,
                    'code'=>200,
                    'message' => $errors[0],
                    'token' => ""
                ], 200);
            }
            // $reqdata = $request->email;
            $credentials =array();
            if($flag == 1)
            {
                $emailExist = Group::where('phone',$request->email)->first(['id','email','status']);
                if(empty($emailExist))
                {
                    return response()->json([
                        'status' => 0,
                        'success' => false,
                        'code'=>200,
                        'message' => "फोन नंबर नहीं मिला",
                        'token' => ""
                    ], 200);
                }
    
                $credentials = array(
                    'phone'=> $request->email,
                    'password'=>$request->password,
                    // 'status'=>'1'
                );
            } if($flag == 2)
            {
                $emailExist = Group::where('logUsername',$request->email)->first(['id','email','status']);
                if(empty($emailExist))
                {
                    return response()->json([
                        'status' => 0,
                        'success' => false,
                        'code'=>200,
                        'message' => "उपयोगकर्ता नाम नहीं मिला",
                        'token' => ""
                    ], 200);
                }
    
                $credentials = array(
                    'logUsername'=> $request->email,
                    'password'=>$request->password,
                    // 'status'=>'1',
                );
            }else if($flag == 0)
            {
                $emailExist = User::where('email',$request->email)->first(['id','email','status']);
                if(empty($emailExist))
                {
                    return response()->json([
                        'status' => 0,
                        'success' => false,
                        'code'=>200,
                        'message' => "ईमेल नहीं मिला ",
                        'token' => ""
                    ], 200);
                }
    
                $credentials = array(
                    'email'=> $request->email,
                    'password'=>$request->password,
                    // 'status'=>'1'
                );
            }
            //Request is validated
            //Crean token
            try {
                if (!$token = JWTAuth::attempt($credentials)) {
                    return response()->json([
                        'status' => 0,
                        'success' => false,
                        'code'=>200,
                        'message' => 'अमान्य क्रेडेंशियल',
                        'token' => ""
                    ], 200);
                }
            } catch (JWTException $e) {
                return $credentials;
                return response()->json([
                    'status' => 0,
                    'success' => false,
                    'code'=>500,
                    'message' => 'टोकन नहीं बना सका',
                    'token' => ""
                ], 500);
            }
    
    
            $reqdata = array(
                'emailMobUser'=> $request->email,
                'password'=>$request->password,
                // 'status'=>'1'
            );
    
    
            if($flag == 1)
            {
                $emailExist = Group::where('phone',$request->email)->first(['id','email','status']);
    
                if(!empty($emailExist))
                {
                    if($emailExist->status == 0)
                    {
                        return response()->json([
                            'status' => 4,
                            'success' => false,
                            'code'=>200,
                            'message' => "क्या आप अपना खाता सक्रिय करना चाहते हैं?",
                            'data' => $reqdata
                        ], 200);
                    }
                }
    
    
    
            } if($flag == 2)
            {
                $emailExist = User::where('logUsername',$request->email)->first(['id','email','status']);
                if(!empty($emailExist))
                {
                    if($emailExist->status == 0)
                    {
                        return response()->json([
                            'status' => 4,
                            'success' => false,
                            'code'=>200,
                            'message' => "क्या आप अपना खाता सक्रिय करना चाहते हैं?",
                            'data' => $reqdata
                        ], 200);
                    }
                }
            }else if($flag == 0)
            {
                $emailExist = User::where('email',$request->email)->first(['id','email','status']);
                if(!empty($emailExist))
                {
                    if($emailExist->status == 0)
                    {
                        return response()->json([
                            'status' => 4,
                            'success' => false,
                            'code'=>200,
                            'message' => "क्या आप अपना खाता सक्रिय करना चाहते हैं?",
                            'data' => $reqdata
                        ], 200);
                    }
                }
            }
    
    
            //Token created, return with success response and jwt token
            return response()->json([
                'status' => 1,
                'success' => true,
                'code'=>200,
                'message' => 'लॉगिन सफलतापूर्वक किया',
                'token' => $token,
            ]);
        }


    }

  
