<?php





include 'config.php'; 

if($_SERVER["REQUEST_METHOD"] == "POST"){

$name = $_POST["name"];
$college = $_POST["college"];
$institute_type = $_POST["institute_type"];
$school_role = $_POST["school_role"];
$phone = $_POST["phone"];

$sql = "INSERT INTO `learnsave`(`name`, `college`, `institute_type`, `school_role`, `phone`)VALUES('$name', '$college'
, '$institute_type', '$school_role', '$phone')";

// chek wether this username 

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
  
  $conn->close();


      
     
    
   
}







?>