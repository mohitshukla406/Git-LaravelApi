<?php 
include 'config.php'; 
if($_SERVER["REQUEST_METHOD"] == "POST"){



$email = $_POST["email"];
$password = $_POST["password"];
$cpassword = $_POST["cpassword"];

// chek wether this username 

$sql = "SELECT * FROM `register` WHERE email ='$email'";
$result = mysqli_query($conn ,$sql);
$numExistRows = mysqli_num_rows($result);
if($numExistRows >0){
    // exits = true
    $showError = "email Alredy Exists";
}else{
    if(($password == $cpassword)){
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO `register`(`email`,`password`,`cpassword`)VALUES('$email','$password','$cpassword' )";
        $result = mysqli_query($conn, $sql);
        if($result){
            header("location: login.php");
        }
    }else{
        // header("location: login.php");
    }
}
}