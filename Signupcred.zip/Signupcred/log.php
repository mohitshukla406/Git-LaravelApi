<?php
include 'config.php';


   




 $email = $_POST['email'];  
$password = $_POST['password'];  
  
    //to prevent from mysqli injection  
    $email = stripcslashes($email);  
    $password = stripcslashes($password);  
    $email = mysqli_real_escape_string($conn, $email);  
    $password = mysqli_real_escape_string($conn, $password);  
  
    $sql = "select *from register where email = '$email' and password = '$password'";  
    $result = mysqli_query($conn, $sql);  
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
    $count = mysqli_num_rows($result);  
      
    if($count == 1){
        $_SESSION['login_user'] = $email;
       header("Location: index.php");

    }  
    else{  
        echo "<h1> Login failed. Invalid username or password.</h1>";  
    }










    if (isset($_POST['login'])) {
        $email = $_POST['email'];
        $pass  = $_POST['password'];
        
        $pass_md5 = md5($pass);
    
        $query = mysqli_query($db_conn,"SELECT * FROM `register` WHERE `email` = '$email' AND `password` = '$pass_md5'");
    
        if(mysqli_num_rows($query) > 0)
        {
          $user = mysqli_fetch_object($query);
          $_SESSION['login'] = true;
          $_SESSION['session_id'] = uniqid();
          
          $user_type = $user->type;
          $_SESSION['user_type'] = $user_type;
          $_SESSION['user_id'] = $user->id;
          header('Location: .'.$user_type.'user.php');
          exit();
        }
        else if ($email == 'email' && $pass == 'password') {
          
          $_SESSION['login'] = true;
          header('Location: .php');
        }
        else {
          echo 'Invailid Credentials';
        }
      }

?>