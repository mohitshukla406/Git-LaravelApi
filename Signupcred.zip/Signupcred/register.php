<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>

  <body style="background-color: #f7f9fc;" >
  <div class="col-md-6" style="margin-top: 50px;">
  <form action="reg.php" method="post">
  <div class="container offset-5 border" style="background: rgb(255, 255, 255);">
  <h3 class="offset-4" style="margin-top: 80px;">Register</h3>
    <div class="form-group col-md-8 offset-2">
      <label for="inputEmail4">Email</label>
      <input type="email" name="email" class="form-control" id="inputEmail4" placeholder="Email" style="background-color: #dbe2ea;">
    </div>
    <div class="form-group col-md-8 offset-2">
      <label for="inputPassword4">Password</label>
      <input type="password" name="password" class="form-control" id="inputPassword4" placeholder="Password" style="background-color: #dbe2ea;">
    </div>
    <div class="form-group col-md-8 offset-2">
      <label for="inputPassword4">CPassword</label>
      <input type="password" name="cpassword" class="form-control" id="inputPassword4" placeholder="Password" style="background-color: #dbe2ea;">
    </div>
    <div class="form-group col-md-8 offset-2">
      <p>By continuing, you agree to our Terms of Service and  Privacy Policy</p>
    </div>
    <div class="row">
    <div class="form-group col-md-8 offset-2 ">
    <button type="submit" class="btn btn-primary ">Register</button>
    <a href="login.php" button type="button" class="btn btn-primary">Login </a>
    

  </div>
  </div>
</form>
</div>
<div style="margin-top: 60px;"></div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

  </body>

</html>